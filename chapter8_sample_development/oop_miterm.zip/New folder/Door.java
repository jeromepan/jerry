package chapter8_sample_development;

public class Door {

    /**
     * Default constructor
     */
    public Door( ) {

    }

//-------------------------------------------------
//      Public Methods:
//
//          void    open     (      )
//
//------------------------------------------------

    /**
     * Simulates the opening of an entrance door
     *
     */
    public void open( ) {
        System.out.println("Door is unlocked. \n" +
                "Welcome to Park Extravaganza\n");
    }
}